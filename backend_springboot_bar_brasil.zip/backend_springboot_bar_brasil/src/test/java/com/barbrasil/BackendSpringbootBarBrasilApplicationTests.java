package com.barbrasil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSpringbootBarBrasilApplicationTests {

	@Test
	void contextLoads() {
	}

}
